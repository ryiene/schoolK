# **Greatsword V3**

[Demo Link](https://jhgfkhgyg.onrender.com/) (Not working anymore because I got banned)

[The Subreddit](https://www.reddit.com/r/swordstuff/)

[Discord Server](https://discord.gg/BMxe6D9CKv)

-------

<img width="960" alt="image" src="https://github.com/Tacogamerman/Greatsword-V3/assets/119009502/73c7f8f1-1994-4ae6-8b4c-51e2b798222a">

-------

<img width="960" alt="image" src="https://github.com/Tacogamerman/Greatsword-V3/assets/119009502/bfb5301a-12c5-4446-86f3-515749599102">


-------

This says 97% html because of the gfiles Lmao

Only deploy this with CodeSandbox and/or Render.

The official link ***is*** going to be slow

# What is Greatsword?
A stupid project made by a dumb kid in middle school.
<br>
This is the sequel to GreatSword v2. Greatsword was an unblocker I made, but it had very outdated scripts and styles compared to new tech. 
<br>
I made this repo to hopefully modernize Greatsword, and keep its feel.
<br>
Please star if you enjoy, it helps this repo grow.

# Important
In order to use "unsafe" Greatsword V3 links you must put your pointer in the middle of the "deceptive site" screen, and type "thisisunsafe". This may redirect you to a new tab, or something else. You may have to go back to the same site and repeat this process up to 10 times. Eventually it will become usable.

# Current bugs:
* Chrome safe browsing may falsely flag links.
* If this happens, about:blank cloak reports as "unsafe" and typing "thisisunsafe" does not work.
# Links:
Discord: https://discord.gg/BMxe6D9CKv

New links ***are*** added to the discord every day.

Credit to this [Gigachad](https://github.com/dragon731012/) for DM Unblocker.

# Other Credits
Orphanlol - Modifying the README (Three times)
<br>
Tacogamerman - Creator of Gsv2
<br>
Skool - Creator of skooleagler
<br>
Cosmosthedev - Provider of an eaglercraft client folder
<br>
I1aw - Provider of Gfiles





